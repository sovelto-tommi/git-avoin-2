const readlineSync = require('readline-sync');
const noppa = require('./kirjastot/noppa');

let tulos = noppa.heita();
console.log('Ekan heiton tulos:', tulos);

let heitetyt = [];
let vastaus;
do {
    for (let index = 0; index < 6; index++) {
        heitetyt.push(noppa.heita());
    }
    console.log('Heitetty 6 noppaa:',heitetyt);
    heitetyt.length = 0;
// eslint-disable-next-line no-cond-assign
} while (vastaus = readlineSync.keyInYN('Jatketaanko?'));
console.log("Hyvähän se sit");

