const noppa = {
    heita : (sivuja = 6) => {
        return Math.floor(Math.random() * sivuja) + 1;
    }
};
module.exports = noppa;